---
marp: false
---

# JaBank

## 1 Cuenta:
In this abstract class I decided to make `Saldo` as a int and `numeroDeSaldo` as a “Integer” to make sure this did not change after it was created and both is as protected for security and to that the class can allows have access to this. The funtions all are protected by the same, without have count the functions get (getSaldo and getNúmeroDeCuenta.
In the case of *retirar*, this have the capacity of throws a excepction when the cuenta don't have enough Saldo (`if(this.Saldo - monto >= 0){...}else{throws new Exception}`). In addition to the functions that we had that make, I made `protected static int getLast_cuenta()` this return the last *cuenta* made, that is save in `private static int last_cuenta;` and finally we've `protected static void setLast_cuenta(Integer new_number)` that change the value of `last_cuenta`. All these are static types to be methods and attributes of the class and of this mode can have constance of when was the last *cuenta*.
### 1.1 Cuenta Vista:
This have his constructor and a funtion `public void transferir(int númeroDeCuenta, int monto)` (this is from the interfaces *Tarjeta*) that implement a Exception to call to `retirar` for the case where this throw a Exception and after use `abonar` from *Cuenta*.
### 1.2 Cuenta Corriente:
Samely that Cuenta Vista, this has a contructor and funcion transferir with the contrast of that have the next:

``` java
try {
    ReadFile.getCuenta(númeroDeCuenta).abonar(monto);

    this.retirar(monto);

} catch (NullPointerException ex) {
    System.out.println("La cuenta :" + númeroDeCuenta + "no ha sido  encontrada");
}
```
For the case where `getCuenta(númeroDeCuenta)` no find the correspont *cuenta*.
This also has its own funtion `retirar` the wich can't throw a Exception because Cuenta Corriente can has negative `Saldo`.
### 1.3 Cuenta de Ahorro:

## 2 FormaDeAhorro:
Interface that implement the correspondents abstracts funtions.
``` java
public abstract int getMonto();
public abstract void actualizar();
```
### 2.1 Fondo Mutuo:

### 2.2 Fondo de Ahorro:

### 2.3 Depósito a Plazo:
This has a `private final float tasa;`, 
by this when the cuenta is created, in the constructor tasa is initialize and after cannot change. Besides also have
``` java
private int dias;
private int monto;
private Cuenta cuenta;
```
All are private to keep the security.

By another way here we have the funtions defined in *FormaDeAhorro* and others.
In the constructor as 
I mentioned, initialize *tasa*
```java
this.tasa = 1f + (FondoMutuo.getCrecimiento() - 1f) / 3;
```
Since Depósito a Plazo need that after of the correspondent days, this remove all and push in the acount.