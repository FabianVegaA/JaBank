package src;

public interface FormaDeAhorro {
    public abstract int getMonto();
    public abstract void actualizar();
}