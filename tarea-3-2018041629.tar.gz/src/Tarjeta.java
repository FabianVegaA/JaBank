package src;

public interface Tarjeta {
    public abstract void transferir(int númeroDeCuenta, int monto);
}